package br.model;

public enum CategoriasCarteira
{
	A, B, C, D, E
}
