package br.utils;

import javax.swing.JOptionPane;

public class Utils
{
	public static void exibirMensagem(String mensagem)
	{
		JOptionPane.showMessageDialog(null, mensagem);
	}
}
