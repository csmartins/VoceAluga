package br.model;

public enum TaxaPagamento
{
	Adiantado, Atrasado, Normal
}
