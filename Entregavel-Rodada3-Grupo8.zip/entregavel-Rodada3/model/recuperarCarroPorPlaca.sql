select * from Carro c
	where c.placa = :placa