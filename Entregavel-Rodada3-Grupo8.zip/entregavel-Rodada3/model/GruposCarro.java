package br.model;

public enum GruposCarro
{

}
